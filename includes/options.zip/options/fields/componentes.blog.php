<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Blog', 'redux-framework-demo' ),
    'id'        => 'comp-blog',
    'desc'      => __( 'Configurações do componente de postagens', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        //Estilos
        array(
            'id'       => 'comp-blog-styles',
            'type'     => 'section',
            'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'comp-blog-total',
            'type'    => 'spinner',
            'title'   => __( 'Quantidade máxima de postagens', 'redux-framework-demo' ),
            'desc'    => __( 'Min: 0 / Max: 3', 'redux-framework-demo' ),
            'default' => '2',
            'min'     => '0',
            'step'    => '1',
            'max'     => '3',
        ),

        array(
            'id'       => 'comp-blog-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#comp-blog'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#f5f5f5',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'comp-blog-post-border',
            'type'     => 'border',
            'title'    => __('Borda da postagen', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.comp-post'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),

        array(
            'id'       => 'comp-blog-post-content',
            'type'     => 'color_rgba',
            'title'    => __( 'Cor de fundo do conteúdo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'default'  => array(
              'color' => '#fff',
              'alpha' => '.6'
            ),
            'output'   => array( '.comp-post > div' ),
            'mode'     => 'background',
            'validate' => 'colorrgba',
        ),

        array(
          'id'       => 'comp-blog-post-content-hover',
          'type'     => 'color_rgba',
          'title'    => __( 'Cor de fundo do conteúdo suspenso', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'default'  => array(
              'color' => '#fff',
              'alpha' => '1'
          ),
          'output'   => array( '.comp-post:hover > div' ),
          'mode'     => 'background',
          'validate' => 'colorrgba',
        ),

        array(
            'id'          => 'comp-blog-cat',
            'type'        => 'typography',
            'title'       => __('Fonte da categoria', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.comp-post > h5'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px'
            ),
        ),

        array(
            'id'          => 'comp-blog-cat',
            'type'        => 'typography',
            'title'       => __('Fonte da categoria', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.comp-post h5'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px'
            ),
        ),

        array(
            'id'          => 'comp-blog-titulo',
            'type'        => 'typography',
            'title'       => __('Fonte do titulo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.comp-post h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '24px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '24px',
                'line-height' => '24px',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'comp-blog-resumo',
            'type'        => 'typography',
            'title'       => __('Fonte do resumo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.comp-post p'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '12px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '12px',
                'line-height' => '12px',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'comp-blog-data',
            'type'        => 'typography',
            'title'       => __('Fonte da data', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.comp-post time'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '12px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'color'   => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '12px',
                'line-height' => '12px',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'       => 'comp-blog-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor das fontes', 'redux-framework-demo' ),
            'output'      => array('.comp-post a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333',
                'hover'   => '#ccc',
                'active'  => '#333',
            ),
        ),

        //Estilos para a campanha
        array(
            'id'       => 'comp-blog-camp-styles',
            'type'     => 'section',
            'title'    => __( 'Opções para o item campanha', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        /*array(
            'id'       => 'comp-blog-camp-bg',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Imagem de fundo da campanha', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
        ),*/

        array( 
            'id'       => 'comp-blog-camp-border',
            'type'     => 'border',
            'title'    => __('Borda', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.comp-post.camp'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),

        //Campanhas
        array(
            'id'       => 'comp-blog-camp-list',
            'type'     => 'section',
            'title'    => __( 'Campanhas', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'comp-blog-camp-active',
            'type'     => 'button_set',
            'title'    => __( 'Ativar campanhas', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //Must provide key => value pairs for radio options
            'options'  => array(
                '1' => 'Ativar',
                '2' => 'Desativar'
            ),
            'default'  => '1'
        ),

        array(
            'id'      => 'comp-blog-camp-total',
            'type'    => 'spinner',
            'title'   => __( 'Quantidade máxima de campanhas', 'redux-framework-demo' ),
            'desc'    => __( 'Min: 0 / Max: 3', 'redux-framework-demo' ),
            'default' => '2',
            'min'     => '0',
            'step'    => '1',
            'max'     => '3',
        ),

        array(
            'id'       => 'comp-blog-camp-ordem',
            'type'     => 'select',
            'title'    => __('Ordem da lista', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'desc'     => __('', 'redux-framework-demo'),
            // Must provide key => value pairs for select options
            'options'  => array(
                '1' => 'Normal',
                '2' => 'Randômica',
            ),
            'default'  => '2',
        ),

        array(
            'id'          => 'comp-blog-camp-items',
            'type'        => 'slides',
            'title'       => __( 'Adicionar campanhas', 'redux-framework-demo' ),
            'subtitle'    => __( 'Adicionar imagens', 'redux-framework-demo' ),
            'desc'        => __( '', 'redux-framework-demo' ),
            'placeholder' => array(
                'title'       => __( 'Título', 'redux-framework-demo' ),
                'description' => __( 'Descrição', 'redux-framework-demo' ),
                'url'         => __( 'Url', 'redux-framework-demo' ),
            ),
        ),
    )
) );

?>