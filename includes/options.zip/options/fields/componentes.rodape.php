<?php
/**
 * Define estilos e elementos para compor o rodapé do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Rodapé', 'redux-framework-demo' ),
    'id'        => 'comp-footer',
    'desc'      => __( 'Configurações do rodapé', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(

        //Estilos
        array(
            'id'       => 'comp-footer-styles',
            'type'     => 'section',
            'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),
        array(
            'id'       => 'comp-footer-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#footer'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#d6d6d6',
            'validate' => 'color',
        ),
        array(
            'id'          => 'comp-footer-endereco',
            'type'        => 'typography',
            'title'       => __('Fonte do endereço', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.address p'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color'       => '#888888',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '14px',
                'line-height' => '14px'
            ),
        ),
        
        //Gmap
        array(
            'id'          => 'comp-footer-gmap',
            'type'        => 'typography',
            'title'       => __('Fonte do endereço no Gmap', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.address p.gmap-link'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '14px',
                'line-height' => '14px'
            ),
        ),

        array(
            'id'       => 'comp-footer-gmap-a',
            'type'     => 'link_color',
            'title'    => __( 'Cor do link para o endereço Gmap', 'redux-framework-demo' ),
            'output'      => array('.address p.gmap-link a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333',
                'hover'   => '#000',
                'active'  => '#333',
            ),
        ),

        //Redes sociais
        array(
            'id'       => 'comp-footer-social',
            'type'     => 'link_color',
            'title'    => __( 'Cor dos links das redes sociais', 'redux-framework-demo' ),
            'output'      => array('#social-footer a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333',
                'hover'   => '#CCC',
                'active'  => '#333',
            ),
        ),

        //Telefones
        array(
            'id'          => 'comp-footer-telefone-font-header',
            'type'        => 'typography',
            'title'       => __('Fonte dos telefones', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.footer-tel h5'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color'       => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '14px',
                'font-weight' => '300',
                'line-height' => '14px'
            ),
        ),

        array(
            'id'          => 'comp-footer-telefone',
            'type'        => 'typography',
            'title'       => __('Fonte dos telefones', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.footer-tel h4, .footer-wapp h4'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color'       => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '22px',
                'line-height' => '22px'
            ),
        ),

        array(
            'id'          => 'comp-footer-wapp',
            'type'        => 'typography',
            'title'       => __('Título para o wathsapp', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.footer-wapp h5'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'color'       => '#1dd28c',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'line-height' => '18px'
            ),
        ),

        array(
            'id'          => 'comp-footer-menu',
            'type'        => 'typography',
            'title'       => __('Fonte do menu', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#footer-menu h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '18px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'line-height' => '18px'
            ),
        ),

        array(
            'id'       => 'comp-footer-menu-link',
            'type'     => 'link_color',
            'title'    => __( 'Link do menu', 'redux-framework-demo' ),
            'output'      => array('#footer-menu a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333',
                'hover'   => '#CCC',
                'active'  => '#333',
            ),
        ),

        array(
            'id'          => 'comp-footer-font-copy',
            'type'        => 'typography',
            'title'       => __('Fonte do copyright', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#credits p'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '18px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '12px',
                'line-height' => '12px'
            ),
        ),
        
        //Textos
        array(
            'id'       => 'comp-footer-txt',
            'type'     => 'section',
            'title'    => __( 'Textos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
          'id'       => 'corp-header',
          'type'     => 'text',
          'title'    => __( 'Cabeçalho do endereço', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'Endereço do escritório',
        ),

        array(
            'id'       => 'comp-footer-telefone-header',
            'type'     => 'text',
            'title'    => __( 'Cabeçalho do telefone', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'default'  => 'Ligue para o ModaBiz',
        ),

        array(
          'id'       => 'comp-footer-copy',
          'type'     => 'text',
          'title'    => __( 'Texto do copyright', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( 'Permitido usar html', 'redux-framework-demo' ),
          'default'  => '2015 Copyright - Todos os direitos reservados à ModaBiz',
        ),

        //Elementos
        array(
            'id'       => 'comp-footer-elements',
            'type'     => 'section',
            'title'    => __( 'Elementos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),
        array(
            'id'       => 'comp-footer-marca',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Imagem para a marca', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/logo.png',
            ),
        ),
        array(
            'id'             => 'comp-footer-marca-altura',
            'type'           => 'dimensions',
            'output'         => array('.logo-footer img'),
            'units'          => array( 'px' ),
            'title'          => __( 'Altura da marca', 'redux-framework-demo' ),
            'subtitle'       => __( '', 'redux-framework-demo' ),
            'desc'           => __( 'A largura será proporciomal', 'redux-framework-demo' ),
            'width'          => false,
            'default'        => array(
                'height' => '80px',
            )
        ),
    )
) );

?>