<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Galeria', 'redux-framework-demo' ),
    'id'        => 'comp-galeria',
    'desc'      => __( 'Configurações do componente de galeria', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        //Estilos
        array(
            'id'       => 'comp-galeria-styles',
            'type'     => 'section',
            'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'comp-galeria-total',
            'type'    => 'spinner',
            'title'   => __( 'Quantidade máxima de items', 'redux-framework-demo' ),
            'desc'    => __( 'Min: 1 / Max: 20', 'redux-framework-demo' ),
            'default' => '4',
            'min'     => '1',
            'step'    => '1',
            'max'     => '20',
        ),

        array(
            'id'       => 'comp-galeria-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#comp-galeria,.reveal-modal'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('Background do componente', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'comp-galeria-border',
            'type'     => 'border',
            'title'    => __('Borda dos itens', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.grid-thumb'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#ffffff', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),

        array(
            'id'          => 'comp-galeria-h2',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#comp-galeria h2'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '30px',
                'line-height' => '30px',
                'text-align'  => 'left',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'comp-galeria-h4',
            'type'        => 'typography',
            'title'       => __('Fonte do subtítulo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#comp-galeria h4'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'text-align'  => 'left',
                'font-weight' => '300'
            ),
        ),

        array(
            'id'       => 'comp-galeria-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor das fontes', 'redux-framework-demo' ),
            'output'      => array('#comp-galeria h2,#comp-galeria h4'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#fff',
                'hover'   => '#eaeaea',
                'active'  => '#fff',
            ),
        ),

        // banner do topo
        array(
            'id'       => 'comp-galeria-banner-top',
            'type'     => 'section',
            'title'    => __( 'Banner do topo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'comp-galeria-banner-top-active',
            'type'     => 'button_set',
            'title'    => __( 'Ativar banner do topo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'options'  => array(
                '1' => 'Ativar',
                '2' => 'Desativar'
            ),
            'default'  => '1'
        ),

        array(
            'id'       => 'comp-galeria-banner-top-bg',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Imagem para o banner', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
        ),

        array(
            'id'       => 'comp-galeria-banner-top-icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone para o título', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
        ),

        array(
            'id'       => 'comp-galeria-banner-top-title',
            'type'     => 'text',
            'title'    => __( 'Título para o banner', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'default'  => '',
        ),

        array(
            'id'       => 'comp-galeria-banner-top-subtitle',
            'type'     => 'text',
            'title'    => __( 'Subtítulo para o banner', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'default'  => '',
        ),

        array(
            'id'       => 'comp-galeria-banner-top-url',
            'type'     => 'text',
            'title'    => __( 'Link para o banner', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'default'  => 'http://modabiz.com.br',
            'validate' => 'url'
        ),

        // banner do rodapé
        array(
            'id'       => 'comp-galeria-banner-bottom',
            'type'     => 'section',
            'title'    => __( 'Banner abaixo do conteúdo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'comp-galeria-banner-bottom-active',
            'type'     => 'button_set',
            'title'    => __( 'Ativar banner do topo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'options'  => array(
                '1' => 'Ativar',
                '2' => 'Desativar'
            ),
            'default'  => '1'
        ),

        array(
            'id'       => 'comp-galeria-banner-bottom-bg',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Imagem para o banner', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
        ),

        array(
            'id'       => 'comp-galeria-banner-bottom-icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone para o título', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
        ),

        array(
            'id'       => 'comp-galeria-banner-bottom-title',
            'type'     => 'text',
            'title'    => __( 'Título para o banner', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'default'  => '',
        ),

        array(
            'id'       => 'comp-galeria-banner-bottom-subtitle',
            'type'     => 'text',
            'title'    => __( 'Subtítulo para o banner', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'default'  => '',
        ),

        array(
            'id'       => 'comp-galeria-banner-bottom-url',
            'type'     => 'text',
            'title'    => __( 'Link para o banner', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'default'  => 'http://modabiz.com.br',
            'validate' => 'url'
        ),
    )
) );

?>