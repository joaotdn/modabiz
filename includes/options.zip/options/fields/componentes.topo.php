<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */

Redux::setSection( $opt_name, array(
    'title'     => __( 'Topo', 'redux-framework-demo' ),
    'id'        => 'comp-topo',
    'desc'      => __( 'Marca e navegação', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(

    	//Estilos
        array(
			'id'       => 'comp-topo-styles',
			'type'     => 'section',
			'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
			'subtitle' => __( '', 'redux-framework-demo' ),
			'indent'   => true,
        ),
        array(
            'id'             => 'comp-topo-altura',
            'type'           => 'dimensions',
            'output'         => array('#main-menu > .row, #main-menu .open-menu'),
            'units'          => array( 'px' ),
            'title'          => __( 'Altura do topo', 'redux-framework-demo' ),
            'subtitle'       => __( '', 'redux-framework-demo' ),
            'desc'           => __( 'A marca possuirá a mesma altura', 'redux-framework-demo' ),
            'width'			 => false,
            'default'        => array(
                'height' => '100px',
            )
        ),
        array(
            'id'       => 'comp-topo-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#main-menu,#main-menu-mo'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('Background do topo', 'redux-framework-demo'),
            'default'  => '#f9f9f9',
            'validate' => 'color',
        ),
        array(
            'id'          => 'app-align-marca',
            'type'        => 'typography',
            'title'       => __('Alinhamento da marca', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => false,
            'output'      => array('#main-menu .d-table-cell, #main-menu-mo .d-table-cell'),
            'units'       =>'px',
            'subtitle'    => __('Alinhar marca no topo do site', 'redux-framework-demo'),

            'preview'     => array(
                'always_display' => false
            ),

            'color'      => false,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,
            'font-family' => false,
            'subsets' => false,
            
            'default'     => array(
                'text-align'  => 'center'
            ),
        ),

        //Elementos
        array(
			'id'       => 'comp-topo-elementos',
			'type'     => 'section',
			'title'    => __( 'Elementos', 'redux-framework-demo' ),
			'subtitle' => __( '', 'redux-framework-demo' ),
			'indent'   => true,
        ),
        array(
            'id'       => 'comp-topo-marca',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Imagem para a marca', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/logo.png',
            ),
        ),
        array(
            'id'       => 'comp-topo-menuicon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone para o menu', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icons/menu.png',
            ),
        ),
        array(
            'id'       => 'comp-topo-menuicon-hover',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone suspenso para o menu', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icons/hover/menu.png',
            ),
        ),

        //Menu
        array(
            'id'       => 'comp-topo-menu',
            'type'     => 'section',
            'title'    => __( 'Estilos para o menu', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),
        array(
            'id'       => 'comp-topo-menu-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#list-menu'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('Background do topo', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),
        array(
            'id'          => 'comp-topo-menu-fonte',
            'type'        => 'typography',
            'title'       => __('Fonte do menu', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#list-menu h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => false
            ),

            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => true,
            'font-backup' => false,
            'font-weight' => false,
            'font-family' => true,
            'subsets' => false,
            
            'default'     => array(
                'font-size'   => '18px',
                'font-family' => 'Open Sans'
            ),
        ),
        array(
            'id'       => 'comp-topo-menu-link',
            'type'     => 'link_color',
            'title'    => __( 'Comportamento dos links', 'redux-framework-demo' ),
            'output'      => array('#list-menu a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#fff',
                'hover'   => '#eaeaea',
                'active'  => '#fff',
            ),
        ),
        array(
            'id'       => 'comp-topo-menuicon-close',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone para fechar o menu', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icons/hover/cross.png',
            ),
        ),
        array(
            'id'          => 'comp-topo-menu-fonte-social',
            'type'        => 'typography',
            'title'       => __('Tamanhos dos ícones das redes sociais', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => false,
            'output'      => array('#list-menu > .social-menu h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => false
            ),

            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,
            'font-family' => false,
            'subsets' => false,
            
            'default'     => array(
                'font-size'   => '32px',
            ),
        ),
        array(
            'id'       => 'comp-topo-menu-link-social',
            'type'     => 'link_color',
            'title'    => __( 'Comportamento dos links das redes sociais', 'redux-framework-demo' ),
            'output'      => array('#list-menu > .social-menu a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#fff',
                'hover'   => '#eaeaea',
                'active'  => '#fff',
            ),
        ),
    )
) );

?>