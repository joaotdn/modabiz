<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Instagram hashtag', 'redux-framework-demo' ),
    'id'        => 'comp-ihash',
    'desc'      => __( 'Fotos para a hashtag do instagram', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(

        array(
              'id'       => 'instagram-hash',
              'type'     => 'text',
              'title'    => __( 'Hashtag para listar imagens', 'redux-framework-demo' ),
              'subtitle' => __( 'Obrigatório (sem "#")', 'redux-framework-demo' ),
              'desc'     => __( '<small class="hash_wait_res"></small>', 'redux-framework-demo' ),
              'default'  => 'modabiz',
        ),

        array(
          'id'       => 'instagram-hash-img-list',
          'type'     => 'callback',
          'title'    => __( 'Resultados da hashtag', 'redux-framework-demo' ),
          'subtitle' => __( 'Fotos mais recentes usando essa hashtag<br><a href="#" class="unselect-us">Desmarcar todas</a>', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'callback' => 'call_hash_imgs',
          'options'  => '',
          'hash'     => Redux::getField($opt_name, 'instagram-token')
        ),

        //Estilos
        array(
            'id'       => 'comp-ihash-styles',
            'type'     => 'section',
            'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'comp-hash-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#instagram-hash'),
            'title'    => __('Cor de fundo do componente', 'redux-framework-demo'),
            'subtitle' => __('Background do componente', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-hash-block-background',
            'type'     => 'color',
            'output'      => array('background-color' => '.hash-block > div'),
            'title'    => __('Cor de fundo do bloco hashtag', 'redux-framework-demo'),
            'subtitle' => __('Background do componente', 'redux-framework-demo'),
            'default'  => '#006699',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-hash-block-font',
            'type'     => 'color',
            'output'      => array('color' => '.hash-block h1, .hash-block h5, .hash-block h3 a'),
            'title'    => __('Cor das fontes', 'redux-framework-demo'),
            'subtitle' => __('Background do componente', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'comp-hash-block-h1',
            'type'        => 'typography',
            'title'       => __('Tamanho do ícone', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.hash-block h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => false,
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,

            'subsets' => false,
            'default'     => array(
                'font-size'   => '40px',
            ),
        ),

        array(
            'id'          => 'comp-hash-block-h5',
            'type'        => 'typography',
            'title'       => __('Fonte da descrição', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.hash-block h5'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '14px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'font-size'   => '14px',
            ),
        ),

        array(
            'id'          => 'comp-hash-block-h3',
            'type'        => 'typography',
            'title'       => __('Fonte da hashtag', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.hash-block h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '14px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'font-size'   => '28px',
                'font-weight' => '800'
            ),
        ),

        array( 
            'id'       => 'comp-hash-block-border',
            'type'     => 'border',
            'title'    => __('Borda do bloco hashtag', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.hash-block > div'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#ffffff', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),
    )
) );

if ( ! function_exists( 'call_hash_imgs' ) ) {
    function call_hash_imgs( $field, $value ) {
        //var_dump(get_option('jt_hash_imgs_cur'));
        echo '<ul class="jt-view-th choose-pics"></ul>';
    }
}

/*if ( ! function_exists( 'call_profile_imgs' ) ) {
    function call_profile_imgs( $field, $value ) {
        //var_dump(get_option('jt_hash_imgs_cur'));
        echo '<ul class="jt-view-profile choose-pics"></ul>';
    }
}*/

?>