<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Blog', 'redux-framework-demo' ),
    'id'        => 'temp-blog',
    'desc'      => __( '', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Tipografia
        array(
            'id'       => 'temp-blog-comp',
            'type'     => 'section',
            'title'    => __( 'Tipografia', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'          => 'temp-blog-title',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.blog-title'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '36px',
                'line-height' => '36px',
                'text-align'  => 'left',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'       => 'temp-blog-title-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor dos títulos', 'redux-framework-demo' ),
            'output'      => array('.blog-title'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#0056bb',
                'hover'   => '#006699',
                'active'  => '#0056bb',
            ),
        ),

        array(
            'id'          => 'temp-blog-font',
            'type'        => 'typography',
            'title'       => __('Demais fontes', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.blog-font'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'font-family' => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans'
            ),
        ),

        //Elementos
        array(
            'id'       => 'temp-blog-ele',
            'type'     => 'section',
            'title'    => __( 'Elementos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-blog-ele-header',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Imagem de fundo do cabeçalho', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' )
        ),

        array(
          'id'       => 'temp-blog-ele-header-mask',
          'type'     => 'color_rgba',
          'title'    => __( 'Máscara', 'redux-framework-demo' ),
          'subtitle' => __( 'Película para background', 'redux-framework-demo' ),
          'default'  => array(
              'color' => '#000',
              'alpha' => '.6'
          ),
          'output'   => array( '.blog-header-mask' ),
          'mode'     => 'background',
          'validate' => 'colorrgba',
        ),

        array(
            'id'       => 'temp-blog-ele-header-color',
            'type'     => 'color',
            'output'      => array('color' => '#blog-header h1, #blog-header h5'),
            'title'    => __('Cor da fonte do cabeçalho', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-blog-ele-header-title',
            'type'        => 'typography',
            'title'       => __('Fonte do título do cabeçalho', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => false,
            'output'      => array('#blog-header h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'font-family' => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'temp-blog-ele-header-desc',
            'type'        => 'typography',
            'title'       => __('Fonte da descrição', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => false,
            'output'      => array('#blog-header h5'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'font-family' => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-weight' => '400'
            ),
        ),

        /*array(
            'id'          => 'temp-blog-font-date',
            'type'        => 'typography',
            'title'       => __('Demais fontes', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#blog-content'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'font-weight' => '300'
            ),
        ),*/

) ));

?>