<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Resposta', 'redux-framework-demo' ),
    'id'        => 'temp-resposta',
    'desc'      => __( '', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Componentes
        array(
            'id'       => 'temp-resposta-comp',
            'type'     => 'section',
            'title'    => __( 'Adicione componentes neste template', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'temp-resposta-blocks-layout',
            'type'     => 'sorter',
            'title'    => 'Compor layout',
            'subtitle' => '',
            'compiler' => 'true',
            'options'  => array(
                'componentes'  => array(
                    'painel' => 'Painel',
                    'cadastro' => 'Cadastro',
                    'blog' => 'Blog',
                    'galeria' => 'Galeria',
                    'instagram-hash' => 'Instagram Hashtag',
                    'instagram-perfil' => 'Instagram perfil',
                    'geolocalizacao' => 'Geolocalização',
                ),
                'topo' => array(),
                'rodape' => array(),
            ),
        ),

        //Estilo da página
        array(
            'id'       => 'temp-resposta-style',
            'type'     => 'section',
            'title'    => __( 'Estilo da página', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'          => 'temp-resposta-type',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#resposta h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '18px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => true,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#006699',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '36px',
                'line-height' => '36px',
                'font-align' => 'center',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'temp-resposta-button',
            'type'        => 'typography',
            'title'       => __('Fonte do botão', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.button-back'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '20px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'text-align'  => 'left'
            ),
        ),

        array(
            'id'       => 'temp-resposta-button-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('.button-back'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333',
                'hover'   => '#fff',
                'active'  => '#fff',
            ),
        ),

        array(
            'id'       => 'temp-resposta-button-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.button-back'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => 'transparent',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-resposta-button-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '.button-back:hover', 'border-color' => '.button-back:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'temp-resposta-button-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.button-back'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),
) ));

?>