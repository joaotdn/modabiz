<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Cadastro', 'redux-framework-demo' ),
    'id'        => 'comp-cadastro',
    'desc'      => __( 'Configurações do componente para cadastro de revendedores', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        //Estilos
        array(
            'id'       => 'comp-cadastro-styles',
            'type'     => 'section',
            'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),
        array(
            'id'       => 'comp-cadastro-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#comp-cadastro'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#f8f8f8',
            'validate' => 'color',
        ),
        array(
            'id'          => 'comp-cadastro-titulo-type',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#comp-cadastro h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '18px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '36px',
                'line-height' => '36px'
            ),
        ),

        array(
            'id'          => 'comp-cadastro-subtitulo-type',
            'type'        => 'typography',
            'title'       => __('Fonte do subtítulo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#comp-cadastro h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '18px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '24px',
                'line-height' => '24px'
            ),
        ),

        array(
            'id'          => 'comp-cadastro-button-font',
            'type'        => 'typography',
            'title'       => __('Fonte do subtítulo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#comp-cadastro h3.cadastro-btn'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '18px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '24px',
                'line-height' => '24px'
            ),
        ),
        
        /**
         * Estilos do botão
         */
        array(
            'id'          => 'comp-cadastro-button',
            'type'        => 'typography',
            'title'       => __('Fonte do botão', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.button-cadastro'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '20px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'text-align'  => 'left'
            ),
        ),

        array(
            'id'       => 'comp-cadastro-button-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('.button-cadastro'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333',
                'hover'   => '#fff',
                'active'  => '#fff',
            ),
        ),

        array(
            'id'       => 'comp-cadastro-button-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.button-cadastro'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => 'transparent',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-cadastro-button-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '.button-cadastro:hover', 'border-color' => '.button-cadastro:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'comp-cadastro-button-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.button-cadastro'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),

        //Textos
        array(
            'id'       => 'comp-cadastro-txt',
            'type'     => 'section',
            'title'    => __( 'Textos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),
        array(
          'id'       => 'comp-cadastro-header',
          'type'     => 'text',
          'title'    => __( 'Título', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'Quer vender no ModaBiz?',
        ),
        array(
          'id'       => 'comp-cadastro-subheader',
          'type'     => 'text',
          'title'    => __( 'Subtítulo', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'Qualidade e estilo que vão fazer seu portfólio venter mais',
        ),
        array(
          'id'       => 'comp-cadastro-button-txt',
          'type'     => 'text',
          'title'    => __( 'Texto do botão', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'CADASTRE-SE AGORA',
        ),

        //Elementos
        array(
            'id'       => 'comp-cadastro-elements',
            'type'     => 'section',
            'title'    => __( 'Elementos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),
        array(
            'id'       => 'comp-cadastro-icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone do título', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/loja.png',
            ),
        ),
        array(
          'id'       => 'comp-cadastro-button-url',
          'type'     => 'text',
          'title'    => __( 'Url do botão', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'http://modabiz.com.br',
          'validate' => 'url'
        ),
    )
) );

?>