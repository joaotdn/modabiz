<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Instagram perfil', 'redux-framework-demo' ),
    'id'        => 'comp-iperfil',
    'desc'      => __( 'Fotos para a perfil do instagram', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(

        array(
            'id'       => 'instagram-username',
            'type'     => 'text',
            'title'    => __( 'Nome do usuário', 'redux-framework-demo' ),
            'subtitle' => __( 'Opcional (impresso no componente)', 'redux-framework-demo' ),
            'desc'     => __( 'Ex.: @modaBiz', 'redux-framework-demo' ),
            'default'  => '@sigamodabiz',
        ),
        array(
            'id'       => 'instagram-userid',
            'type'     => 'text',
            'title'    => __( 'Id do usuário', 'redux-framework-demo' ),
            'subtitle' => __( 'Obrigatório (Apenas números)', 'redux-framework-demo' ),
            'desc'     => __( '<a href="http://www.otzberg.net/iguserid/" target="_blank">Encontre seu ID aqui</a><br><small class="hash_wait_res"></small>', 'redux-framework-demo' ),
            'default'  => '1943410735',
        ),
        array(
            'id'       => 'instagram-profile-img-list',
            'type'     => 'callback',
            'title'    => __( 'Resultados das fotos no perfil', 'redux-framework-demo' ),
            'subtitle' => __( 'Fotos públicas mais recentes do perfil<br><a href="#" class="unselect-us">Desmarcar todas</a>', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'callback' => 'call_profile_imgs'
        ),

        //Estilos
        array(
            'id'       => 'comp-iperfil-styles',
            'type'     => 'section',
            'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'comp-perfil-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#instagram-perfil'),
            'title'    => __('Cor de fundo do componente', 'redux-framework-demo'),
            'subtitle' => __('Background do componente', 'redux-framework-demo'),
            'default'  => '#f5f5f5',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-perfil-block-background',
            'type'     => 'color',
            'output'      => array('background-color' => '.profile-block > div'),
            'title'    => __('Cor de fundo do bloco perfil', 'redux-framework-demo'),
            'subtitle' => __('Background do componente', 'redux-framework-demo'),
            'default'  => 'transparent',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-perfil-block-font',
            'type'     => 'color',
            'output'      => array('color' => '.profile-block h1, .profile-block h5, .profile-block h3 > a'),
            'title'    => __('Cor das fontes', 'redux-framework-demo'),
            'subtitle' => __('Background do componente', 'redux-framework-demo'),
            'default'  => '#006699',
            'validate' => 'color',
        ),

        array(
            'id'          => 'comp-perfil-block-h1',
            'type'        => 'typography',
            'title'       => __('Tamanho do ícone', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.profile-block h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => false,
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,

            'subsets' => false,
            'default'     => array(
                'font-size'   => '40px',
            ),
        ),

        array(
            'id'          => 'comp-perfil-block-h3',
            'type'        => 'typography',
            'title'       => __('Fonte da perfil', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.profile-block h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '14px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'font-size'   => '28px',
                'font-weight' => '800'
            ),
        ),

        array( 
            'id'       => 'comp-perfil-block-border',
            'type'     => 'border',
            'title'    => __('Borda do bloco perfil', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.profile-block > div'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#006699', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),
    )
) );

if ( ! function_exists( 'call_profile_imgs' ) ) {
    function call_profile_imgs( $field, $value ) {
        //var_dump(get_option('jt_hash_imgs_cur'));
        echo '<ul class="jt-view-profile choose-pics"></ul>';
    }
}

?>