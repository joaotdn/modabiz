<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Lookbook', 'redux-framework-demo' ),
    'id'        => 'temp-cole',
    'desc'      => __( '', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Componentes
        array(
            'id'       => 'temp-cole-comp',
            'type'     => 'section',
            'title'    => __( 'Adicione componentes neste template', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'temp-cole-blocks-layout',
            'type'     => 'sorter',
            'title'    => 'Compor layout',
            'subtitle' => '',
            'compiler' => 'true',
            'options'  => array(
                'componentes'  => array(
                    'painel' => 'Painel',
                    'cadastro' => 'Cadastro',
                    'blog' => 'Blog',
                    'galeria' => 'Galeria',
                    'instagram-hash' => 'Instagram Hashtag',
                    'instagram-perfil' => 'Instagram perfil',
                    'geolocalizacao' => 'Geolocalização',
                ),
                'topo' => array(),
                'rodape' => array(),
            ),
        ),

        //Página
        array(
            'id'       => 'temp-cole-top',
            'type'     => 'section',
            'title'    => __( 'Estilo da página', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-cole-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#inner-look'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#f1f1f1',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-cole-title',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#inner-look header h1, .meter-title'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '36px',
                'line-height' => '36px',
                'text-align'  => 'left',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'       => 'temp-cole-slide',
            'type'     => 'section',
            'title'    => __( 'Estilo do slider', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'             => 'temp-cole-altura',
            'type'           => 'dimensions',
            'output'         => array('#look-slider, .list-items-look'),
            'units'          => array( 'px','em' ),
            'title'          => __( 'Altura do slider', 'redux-framework-demo' ),
            'subtitle'       => __( '', 'redux-framework-demo' ),
            'desc'           => __( '', 'redux-framework-demo' ),
            'width'          => false,
            'default'        => array(
                'height' => '995px',
            )
        ),

        array(
            'id'       => 'temp-cole-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.list-items-look figure, #campaing-carousel'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-cole-choices-border',
            'type'     => 'color',
            'output'      => array('border-color' => '#item-choices a'),
            'title'    => __('Cor da borda das opções de itens', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-cole-choices-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '#item-choices a'),
            'title'    => __('Cor de fundo das opções de itens', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-cole-choices-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '#item-choices a:hover', 'border-color' => '#item-choices a:hover'),
            'title'    => __('Cor de fundo das opções de itens suspenso', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-cole-choices-share',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone compartilhar', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icons/share2.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-choices-share-hover',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone compartilhar suspenso', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icons/hover/share2.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-choices-meter',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone medidas', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/meter.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-choices-meter-hover',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone medidas suspenso', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/meter-hover.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-choices-gift',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone presente', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icons/gift.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-choices-gift-hover',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone presente suspenso', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icons/hover/gift.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-choices-sacola',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone loja', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/sacola.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-choices-sacola-hover',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone loja suspenso', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/sacola-hover.png',
            ),
        ),

        array(
            'id'       => 'temp-cole-icon-share',
            'type'     => 'color',
            'output'      => array('color' => '.share-look a'),
            'title'    => __('Cor dos ícones sociais', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-cole-icon-share-hover',
            'type'     => 'color',
            'output'      => array('color' => '.share-look a:hover'),
            'title'    => __('Cor dos ícones sociais suspenso', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-cole-meters-fonte',
            'type'        => 'typography',
            'title'       => __('Fonte da caixa de medidas', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.meters-modal li'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'font-weight' => '300'
            ),
        ),

        array(
            'id'       => 'temp-cole-nav-button-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor das setas de navegação', 'redux-framework-demo' ),
            'output'      => array('.nav-thumbs, .nav-lookbook'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#fff',
                'hover'   => '#c00',
                'active'  => '#fff',
            ),
        ),

        
) ));

?>