<?php

//Redes sociais
Redux::setSection( $opt_name, array(
    'title'     => __( 'Tipografia', 'redux-framework-demo' ),
    'id'        => 'opc-tipografia',
    'desc'      => __( 'Fontes da aplicação', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
      //cabeçalho de nivel 1
      array(
        'id'          => 'app-h1',
        'type'        => 'typography',
        'title'       => __('Cabeçalho 1', 'redux-framework-demo'),
        'compiler'    => true,
        'google'      => true,
        'output'      => array('h1'),
        'units'       =>'px',
        'subtitle'    => __('Cabeçalhos de primeiro nível', 'redux-framework-demo'),
        'preview'     => array(
            'always_display' => true,
            'font-size'   => '30px',
        ),
        
        'color'      => false,
        'font-size'   => true,
        'line-height' => true,
        'text-align'  => false,
        'font-style'  => false,
        'font-backup' => false,
        'font-weight' => true,

        'subsets' => false,
        'default'     => array(
            'font-family' => 'Open Sans',
            'google'      => true,
            'font-size'   => '40px',
            'line-height' => '40px',
            'text-align'  => 'left'
        ),
      ),
      
      //Caeçalho de nível 2
      array(
        'id'          => 'app-h2',
        'type'        => 'typography',
        'title'       => __('Cabeçalho 2', 'redux-framework-demo'),
        'compiler'    => true,
        'google'      => true,
        'output'      => array('h2'),
        'units'       =>'px',
        'subtitle'    => __('Cabeçalhos de segundo nível', 'redux-framework-demo'),
        'preview'     => array(
            'always_display' => true,
            'font-size'   => '26px',
        ),
        
        'color'      => false,
        'font-size'   => true,
        'line-height' => true,
        'text-align'  => false,
        'font-style'  => false,
        'font-backup' => false,
        'font-weight' => true,

        'subsets' => false,
        'default'     => array(
            'font-family' => 'Open Sans',
            'google'      => true,
            'font-size'   => '26px',
            'line-height' => '26px',
            'text-align'  => 'left'
        ),
      ),

      //Caeçalho de nível 3
      array(
        'id'          => 'app-h3',
        'type'        => 'typography',
        'title'       => __('Cabeçalho 3', 'redux-framework-demo'),
        'compiler'    => true,
        'google'      => true,
        'output'      => array('h3'),
        'units'       =>'px',
        'subtitle'    => __('Cabeçalhos de terceiro nível', 'redux-framework-demo'),
        'preview'     => array(
            'always_display' => true,
            'font-size'   => '24px',
        ),
        
        'color'      => false,
        'font-size'   => true,
        'line-height' => true,
        'text-align'  => false,
        'font-style'  => false,
        'font-backup' => false,
        'font-weight' => true,

        'subsets' => false,
        'default'     => array(
            'font-family' => 'Open Sans',
            'google'      => true,
            'font-size'   => '24px',
            'line-height' => '24px',
            'text-align'  => 'left'
        ),
      ),

      //Caeçalho de nível 4
      array(
        'id'          => 'app-h4',
        'type'        => 'typography',
        'title'       => __('Cabeçalho 4', 'redux-framework-demo'),
        'compiler'    => true,
        'google'      => true,
        'output'      => array('h4'),
        'units'       =>'px',
        'subtitle'    => __('Cabeçalhos de quarto nível', 'redux-framework-demo'),
        'preview'     => array(
            'always_display' => true,
            'font-size'   => '20px',
        ),
        
        'color'      => false,
        'font-size'   => true,
        'line-height' => true,
        'text-align'  => false,
        'font-style'  => false,
        'font-backup' => false,
        'font-weight' => true,

        'subsets' => false,
        'default'     => array(
            'font-family' => 'Open Sans',
            'google'      => true,
            'font-size'   => '20px',
            'line-height' => '20px',
            'text-align'  => 'left'
        ),
      ),

      //Caeçalho de nível 4
      array(
        'id'          => 'app-p',
        'type'        => 'typography',
        'title'       => __('Parágrafos', 'redux-framework-demo'),
        'compiler'    => true,
        'google'      => true,
        'output'      => array('p'),
        'units'       =>'px',
        'subtitle'    => __('Estilo geral para parágrafos', 'redux-framework-demo'),
        'preview'     => array(
            'always_display' => true,
            'font-size'   => '16px',
        ),
        
        'color'      => false,
        'font-size'   => true,
        'line-height' => true,
        'text-align'  => false,
        'font-style'  => false,
        'font-backup' => false,
        'font-weight' => true,

        'subsets' => false,
        'default'     => array(
            'font-family' => 'Open Sans',
            'google'      => true,
            'font-size'   => '16px',
            'line-height' => '16px',
            'text-align'  => 'left'
        ),
      ),
    )
) );

?>