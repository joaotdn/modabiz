<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Painel', 'redux-framework-demo' ),
    'id'        => 'comp-painel',
    'desc'      => __( 'Configurações do slider', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(

        //Estilos
        array(
            'id'       => 'comp-painel-styles',
            'type'     => 'section',
            'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),
        array(
            'id'      => 'comp-painel-total',
            'type'    => 'spinner',
            'title'   => __( 'Quantidade máxima de sliders', 'redux-framework-demo' ),
            'desc'    => __( 'Min: 1 / Max: 6', 'redux-framework-demo' ),
            'default' => '1',
            'min'     => '1',
            'step'    => '1',
            'max'     => '6',
        ),
        array(
            'id'             => 'comp-painel-altura',
            'type'           => 'dimensions',
            'output'         => array('#main-painel'),
            'units'          => array( 'px','em' ),
            'title'          => __( 'Altura do painel', 'redux-framework-demo' ),
            'subtitle'       => __( '', 'redux-framework-demo' ),
            'desc'           => __( '', 'redux-framework-demo' ),
            'width'          => false,
            'default'        => array(
                'height' => '800px',
            )
        ),
        array(
            'id'       => 'comp-painel-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#main-painel'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),
        array(
          'id'       => 'comp-painel-mask',
          'type'     => 'color_rgba',
          'title'    => __( 'Máscara', 'redux-framework-demo' ),
          'subtitle' => __( 'Película para background', 'redux-framework-demo' ),
          'default'  => array(
              'color' => '#000',
              'alpha' => '.6'
          ),
          'output'   => array( '.slider-mask' ),
          'mode'     => 'background',
          'validate' => 'colorrgba',
        ),
        array(
            'id'       => 'comp-painel-loader',
            'type'     => 'color',
            'output'      => array('color' => '#main-painel .icon-spinner8'),
            'title'    => __('Cor do loader', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),
        array(
            'id'       => 'comp-painel-arrows',
            'type'     => 'color',
            'output'      => array('color' => '#main-painel .nav-painel'),
            'title'    => __('Cor das setas de navegação', 'redux-framework-demo'), 
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),

        /**
         * Estilos do titulo
         */
        array(
            'id'          => 'comp-painel-h1',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#main-painel h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '40px',
                'line-height' => '40px',
                'text-align'  => 'left'
            ),
        ),
        array(
            'id'       => 'comp-painel-h1-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor do título', 'redux-framework-demo' ),
            'output'      => array('#main-painel h1 a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#fff',
                'hover'   => '#eaeaea',
                'active'  => '#fff',
            ),
        ),

        /**
         * Estilos do subtitulo
         */
        array(
            'id'          => 'comp-painel-h3',
            'type'        => 'typography',
            'title'       => __('Fonte do subtítulo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#main-painel h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '20px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '20px',
                'line-height' => '20px',
                'text-align'  => 'left'
            ),
        ),

        array(
            'id'       => 'comp-painel-h3-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor do subtítulo', 'redux-framework-demo' ),
            'output'      => array('#main-painel h3 a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#fff',
                'hover'   => '#eaeaea',
                'active'  => '#fff',
            ),
        ),

        /**
         * Estilos do botão
         */
        array(
            'id'          => 'comp-painel-button',
            'type'        => 'typography',
            'title'       => __('Fonte do botão', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#main-painel .slider-button'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '20px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,

            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'text-align'  => 'left'
            ),
        ),

        array(
            'id'       => 'comp-painel-button-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('#main-painel .slider-button'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#fff',
                'hover'   => '#eaeaea',
                'active'  => '#fff',
            ),
        ),

        array(
            'id'       => 'comp-painel-button-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '#main-painel .slider-button'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-painel-button-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '#main-painel .slider-button:hover', 'border-color' => '#main-painel .slider-button:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'comp-painel-button-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('#main-painel .slider-button'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#FFFFFF', 
                'border-style'  => 'solid', 
                'border-top'    => '6px', 
                'border-right'  => '6px', 
                'border-bottom' => '6px', 
                'border-left'   => '6px'
            )
        ),

        /**
         * Marcadores
         */
        array(
            'id'       => 'comp-painel-controls',
            'type'     => 'color',
            'output'      => array('border-color' => '.owl-theme .owl-controls .owl-page span','background-color' => '.owl-theme .owl-controls .owl-page span'),
            'title'    => __('Cor do marcador', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#FFFFFF',
            'validate' => 'color',
        ),
    )
) );

?>