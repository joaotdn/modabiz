<?php

Redux::setSection( $opt_name, array(
    'title'     => __( 'Institucional', 'redux-framework-demo' ),
    'id'        => 'corporation',
    'desc'      => __( 'Dados de contato da entidade', 'redux-framework-demo' ),
    'icon'      => 'el el-group',
    'fields'    => array(
      array(
          'id'       => 'corp-rua',
          'type'     => 'text',
          'title'    => __( 'Rua, Número', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'Rua Francisco de Assis Frade, 150',
      ),
      array(
          'id'       => 'corp-complemento',
          'type'     => 'text',
          'title'    => __( 'Complemento', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => '',
      ),
      array(
          'id'       => 'corp-bairro',
          'type'     => 'text',
          'title'    => __( 'Bairro', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'Manaíra',
      ),
      array(
          'id'       => 'corp-cep',
          'type'     => 'text',
          'title'    => __( 'CEP', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => '',
      ),
      array(
          'id'       => 'corp-cidade',
          'type'     => 'text',
          'title'    => __( 'Cidade - UF', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'João Pessoa - PB',
      ),
      array(
          'id'       => 'corp-telefone',
          'type'     => 'multi_text',
          'title'    => __( 'Telefones', 'redux-framework-demo' ),
          'subtitle' => __( 'O primeiro telefone será o principal', 'redux-framework-demo' ),
          'desc'     => __( 'Ex.: (83) 9898-9898', 'redux-framework-demo' ),
          'default'  => array('83 3513.9633'),
      ),
      array(
          'id'       => 'corp-email',
          'type'     => 'text',
          'title'    => __( 'Email principal', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( 'Coloque aqui o email primário da empresa', 'redux-framework-demo' ),
          'default'  => 'contato@modabiz.com.br',
      ),
      array(
          'id'       => 'corp-horario',
          'type'     => 'text',
          'title'    => __( 'Horário de funcionamento', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => '08h às 17h30, de seg. à sex. e de 08h às 12h30 aos sábados',
      ),
      array(
          'id'       => 'corp-loja',
          'type'     => 'text',
          'title'    => __( 'Link da loja virtual', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( 'Link completo da loja', 'redux-framework-demo' ),
          'default'  => '',
      ),
      array(
          'id'       => 'corp-map',
          'type'     => 'text',
          'title'    => __( 'Link no Google Maps', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( 'Link do mapa', 'redux-framework-demo' ),
          'default'  => '',
      )
    )
) );

//Redes sociais
Redux::setSection( $opt_name, array(
    'title'     => __( 'Redes sociais', 'redux-framework-demo' ),
    'id'        => 'corp-social',
    'desc'      => __( 'Principais redes sociais da entidade', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
      array(
          'id'       => 'corp-facebook',
          'type'     => 'text',
          'title'    => __( 'Link da fanpage', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'https://www.facebook.com/sigamodabiz/timeline',
          'validate' => 'url',
      ),
      array(
          'id'       => 'corp-instagram',
          'type'     => 'text',
          'title'    => __( 'Link para o Instagram', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'https://instagram.com/sigamodabiz/',
          'validate' => 'url',
      ),
      array(
          'id'       => 'corp-twitter',
          'type'     => 'text',
          'title'    => __( 'Link da fanpage', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( '', 'redux-framework-demo' ),
          'default'  => 'https://www.twitter.com/sigamodabiz',
          'validate' => 'url',
      ),
      array(
          'id'       => 'corp-whatsapp',
          'type'     => 'text',
          'title'    => __( 'Número do whatsapp', 'redux-framework-demo' ),
          'subtitle' => __( '', 'redux-framework-demo' ),
          'desc'     => __( 'ex.: (81) 98899-6754', 'redux-framework-demo' ),
          'default'  => '',
      ),
    )
) );

?>