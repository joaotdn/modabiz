<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Coleção', 'redux-framework-demo' ),
    'id'        => 'temp-look',
    'desc'      => __( '', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Componentes
        array(
            'id'       => 'temp-look-comp',
            'type'     => 'section',
            'title'    => __( 'Adicione componentes neste template', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'temp-look-blocks-layout',
            'type'     => 'sorter',
            'title'    => 'Compor layout',
            'subtitle' => '',
            'compiler' => 'true',
            'options'  => array(
                'componentes'  => array(
                    'painel' => 'Painel',
                    'cadastro' => 'Cadastro',
                    'blog' => 'Blog',
                    'galeria' => 'Galeria',
                    'instagram-hash' => 'Instagram Hashtag',
                    'instagram-perfil' => 'Instagram perfil',
                    'geolocalizacao' => 'Geolocalização',
                ),
                'topo' => array(),
                'rodape' => array(),
            ),
        ),

        //Estilo do topo
        array(
            'id'       => 'temp-look-top',
            'type'     => 'section',
            'title'    => __( 'Estilo do cabeçalho', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-look-rgba',
            'type'     => 'color_rgba',
            'title'    => __( 'Máscara para o background', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'output'      => array('background-color' => '#look-header .mask'),
            'default'  => array(
                'color' => '#333333',
                'alpha' => '.8'
            ),
            //'output'   => array( 'body' ),
            'mode'     => 'background',
            'validate' => 'colorrgba',
        ),

        array(
            'id'          => 'temp-marca-info-titles',
            'type'        => 'typography',
            'title'       => __('Fonte dos títulos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#look-header h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#ffffff',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '46px',
                'line-height' => '46px',
                'font-weight' => '800'
            ),
        ),

        //Estilo da listagem
        array(
            'id'       => 'temp-look-list',
            'type'     => 'section',
            'title'    => __( 'Estilo da listagem', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-look-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#temp-look'),
            'title'    => __('Cor de fundo da página', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-marca-item-titles',
            'type'        => 'typography',
            'title'       => __('Título do item', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#look-list h2'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#ffffff',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '32px',
                'line-height' => '32px',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'temp-marca-item-subtitles',
            'type'        => 'typography',
            'title'       => __('Subtítulo do item', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#look-list h4'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#ffffff',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'font-weight' => '800'
            ),
        ),

        array( 
            'id'       => 'temp-item-border',
            'type'     => 'border',
            'title'    => __('Borda do item', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('#look-list .grid-item > a'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '4px', 
                'border-right'  => '4px', 
                'border-bottom' => '4px', 
                'border-left'   => '4px'
            )
        ),
) ));

?>