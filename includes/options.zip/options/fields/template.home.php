<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Homepage', 'redux-framework-demo' ),
    'id'        => 'temp-home',
    'desc'      => __( 'Compor página principal', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Componentes
        array(
            'id'       => 'temp-home-comp',
            'type'     => 'section',
            'title'    => __( 'Componentes visíveis na página principal', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'temp-home-blocks-layout',
            'type'     => 'sorter',
            'title'    => 'Compor layout',
            'subtitle' => '',
            'compiler' => 'true',
            'options'  => array(
                'componentes'  => array(
                    'painel' => 'Painel',
                    'cadastro' => 'Cadastro',
                    'blog' => 'Blog',
                    'galeria' => 'Galeria',
                    'instagram-hash' => 'Instagram Hashtag',
                    'instagram-perfil' => 'Instagram perfil',
                    'geolocalizacao' => 'Geolocalização',
                ),
                'template' => array(),
            ),
        )
) ));

?>