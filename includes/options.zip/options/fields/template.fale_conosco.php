<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Fale conosco', 'redux-framework-demo' ),
    'id'        => 'temp-contato',
    'desc'      => __( '', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Componentes
        array(
            'id'       => 'temp-contato-comp',
            'type'     => 'section',
            'title'    => __( 'Adicione componentes neste template', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'temp-contato-blocks-layout',
            'type'     => 'sorter',
            'title'    => 'Compor layout',
            'subtitle' => '',
            'compiler' => 'true',
            'options'  => array(
                'componentes'  => array(
                    'painel' => 'Painel',
                    'cadastro' => 'Cadastro',
                    'blog' => 'Blog',
                    'galeria' => 'Galeria',
                    'instagram-hash' => 'Instagram Hashtag',
                    'instagram-perfil' => 'Instagram perfil',
                    'geolocalizacao' => 'Geolocalização',
                ),
                'topo' => array(),
                'rodape' => array(),
            ),
        ),

        /**
         * Estilo da página
         */
        array(
            'id'       => 'temp-contato-style-info',
            'type'     => 'section',
            'title'    => __( 'Estilo da página', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-contato-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#inner-contato'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-contato-title',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#inner-contato h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '36px',
                'line-height' => '36px',
                'text-align'  => 'left',
                'font-weight' => '800'
            ),
        ),
        
        /**
         * Estilo do formularios
         */
        array(
            'id'       => 'temp-contato-style-form',
            'type'     => 'section',
            'title'    => __( 'Estilo do formulário', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'          => 'temp-contato-style-form-font',
            'type'        => 'typography',
            'title'       => __('Fonte', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#contact-form h2, #contact-form h3, #contact-form input, #contact-form span, #contact-form label, #contact-form select, #contact-form textarea'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'font-family' => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
            ),
        ),

        array(
            'id'          => 'temp-contato-style-form-input-font',
            'type'        => 'typography',
            'title'       => __('Fonte dos inputs', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#contact-form input, #contact-form nav a, #contact-form select, #contact-form textarea'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => false,
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => false,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => true,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
            ),
        ),

        array( 
            'id'       => 'temp-contato-style-form-input-border',
            'type'     => 'border',
            'title'    => __('Borda do input', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('#contact-form input, #contact-form select, #contact-form textarea'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#999', 
                'border-style'  => 'solid', 
                'border-top'    => '1px', 
                'border-right'  => '1px', 
                'border-bottom' => '1px', 
                'border-left'   => '1px'
            )
        ),

        array(
            'id'          => 'temp-contato-style-form-btn',
            'type'        => 'typography',
            'title'       => __('Fonte do botão', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.contato-form-btn'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'       => 'temp-contato-style-form-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('.contato-form-btn'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333333',
                'hover'   => '#eaeaea',
                'active'  => '#333333',
            ),
        ),

        array(
            'id'       => 'temp-contato-style-form-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.contato-form-btn'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-contato-style-form-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '.contato-form-btn:hover', 'border-color' => '.contato-form-btn:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'temp-contato-style-form-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.contato-form-btn'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '4px', 
                'border-right'  => '4px', 
                'border-bottom' => '4px', 
                'border-left'   => '4px'
            )
        ),

        /**
         * Estilo das informações
         */
        array(
            'id'       => 'temp-contato-style-info',
            'type'     => 'section',
            'title'    => __( 'Estilo das informações', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'          => 'temp-contato-info-titles',
            'type'        => 'typography',
            'title'       => __('Fonte dos títulos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.title-info'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'          => 'temp-contato-info-content',
            'type'        => 'typography',
            'title'       => __('Fonte das informações', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.content-info'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '400'
            ),
        ),
) ));

?>