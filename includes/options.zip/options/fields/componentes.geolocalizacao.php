<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */

Redux::setSection( $opt_name, array(
    'title'     => __( 'Geolocalização', 'redux-framework-demo' ),
    'id'        => 'comp-geo',
    'desc'      => __( 'Comportamento do componente Gmap', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(

        //Geral
        array(
            'id'       => 'comp-geo-geral',
            'type'     => 'section',
            'title'    => __( 'Opções gerais', 'redux-framework-demo' ),
            'subtitle' => __( 'Configurações do comportamento inicial do mapa', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
              'id'       => 'comp-geo-api',
              'type'     => 'text',
              'title'    => __( 'Chave API', 'redux-framework-demo' ),
              'subtitle' => __( '', 'redux-framework-demo' ),
              'desc'     => __( 'Deve ser gerada nas credenciais da Google', 'redux-framework-demo' ),
              'default'  => 'AIzaSyB664XOo1V2z76RD87sMi4b4nAM1JzKthg',
        ),

        array(
              'id'       => 'comp-geo-lat',
              'type'     => 'text',
              'title'    => __( 'Latitude inicial', 'redux-framework-demo' ),
              'subtitle' => __( '', 'redux-framework-demo' ),
              'desc'     => __( '', 'redux-framework-demo' ),
              'default'  => '-7.098023',
        ),

        array(
              'id'       => 'comp-geo-lng',
              'type'     => 'text',
              'title'    => __( 'Longitude inicial', 'redux-framework-demo' ),
              'subtitle' => __( '', 'redux-framework-demo' ),
              'desc'     => __( '', 'redux-framework-demo' ),
              'default'  => '-34.842957',
        ),

        array(
            'id'       => 'comp-geo-icon-normal',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone da localização', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icon.png',
            ),
        ),

        array(
            'id'       => 'comp-geo-icon-hover',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone da localização suspenso', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icon.png',
            ),
        ),

        array(
            'id'       => 'comp-geo-icon-user',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone da localização do usuário', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/usericon.png',
            ),
        ),

    	//Estilos
        array(
			'id'       => 'comp-geo-styles',
			'type'     => 'section',
			'title'    => __( 'Opções de estilo', 'redux-framework-demo' ),
			'subtitle' => __( '', 'redux-framework-demo' ),
			'indent'   => true,
        ),

        array(
            'id'       => 'comp-geo-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#comp-geo'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('Componente', 'redux-framework-demo'),
            'default'  => '#f5f5f5',
            'validate' => 'color',
        ),

        /*array(
            'id'             => 'comp-geo-map-altura',
            'type'           => 'dimensions',
            'output'         => array('#map-layer'),
            'units'          => array( 'px','em' ),
            'title'          => __( 'Altura do mapa', 'redux-framework-demo' ),
            'subtitle'       => __( '', 'redux-framework-demo' ),
            'desc'           => __( '', 'redux-framework-demo' ),
            'width'          => false,
            'default'        => array(
                'height' => '600px',
            )
        ),*/

        array(
            'id'          => 'comp-geo-btninput-font',
            'type'        => 'typography',
            'title'       => __('Tamanho da fonte do botão e buscador', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => false,
            'output'      => array('.geo-btn,input.geo-input,#comp-geo input[type="text"]'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => false,
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,
            'font-family' => false,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'          => 'comp-geo-h1',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#comp-geo h2'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'color'       => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '36px',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'comp-geo-btn-font',
            'type'        => 'typography',
            'title'       => __('Fonte do botão geolocation', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.geo-btn'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'       => 'comp-geo-btn-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('.geo-btn'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333333',
                'hover'   => '#eaeaea',
                'active'  => '#333333',
            ),
        ),

        array(
            'id'       => 'comp-geo-button-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.geo-btn'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-geo-button-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '.geo-btn:hover', 'border-color' => '.geo-btn:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'comp-geo-button-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.geo-btn'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '4px', 
                'border-right'  => '4px', 
                'border-bottom' => '4px', 
                'border-left'   => '4px'
            )
        ),

        array( //input
            'id'          => 'comp-geo-input-font',
            'type'        => 'typography',
            'title'       => __('Fonte do input', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#comp-geo input[type="text"], .search-location'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'color'       => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '400'
            ),
        ),

        array(
            'id'       => 'comp-geo-input-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '#comp-geo input[type="text"]'),
            'title'    => __('Cor de fundo do input', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#d9d9d9',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'comp-geo-input-border',
            'type'     => 'border',
            'title'    => __('Borda do input', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('#comp-geo input[type="text"]'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#ffffff', 
                'border-style'  => 'solid', 
                'border-top'    => '4px', 
                'border-right'  => '4px', 
                'border-bottom' => '4px', 
                'border-left'   => '4px'
            )
        ),

        //Estilos das informações
        array(
            'id'       => 'comp-geo-styles-info',
            'type'     => 'section',
            'title'    => __( 'Opções para as informações do local', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'comp-geo-info-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '#map-info'),
            'title'    => __('Cor de fundo do input', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#f1f1f1',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-geo-info-icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone do título', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icon-map.png',
            ),
        ),

        array( //input
            'id'          => 'comp-geo-info-title-font',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#map-info h1[data-title]'),
            'units'       => array('px','em'),
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '26px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'color'       => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '26px',
                'font-height'   => '26px',
                'font-weight' => '800'
            ),
        ),

        array( //input
            'id'          => 'comp-geo-info-tipo-font',
            'type'        => 'typography',
            'title'       => __('Fonte do tipo de revenda', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#map-info h1[data-tipo]'),
            'units'       => array('px','em'),
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '14px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'color'       => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '14px',
                'font-height'   => '14px',
                'font-weight' => '300'
            ),
        ),

        array( //input
            'id'          => 'comp-geo-info-address-font',
            'type'        => 'typography',
            'title'       => __('Fonte do endereço/contato', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#map-info p'),
            'units'       => array('px','em'),
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'color'       => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'font-height'   => '16px',
                'font-weight' => '400'
            ),
        ),

        array(
            'id'       => 'comp-geo-social',
            'type'     => 'link_color',
            'title'    => __( 'Redes sociais', 'redux-framework-demo' ),
            'output'      => array('#map-info li a','#map-info .icon-cross'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333333',
                'hover'   => '#eaeaea',
                'active'  => '#fff',
            ),
        ),

        //Textos
        array(
            'id'       => 'comp-geo-txt',
            'type'     => 'section',
            'title'    => __( 'Textos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
              'id'       => 'comp-geo-header',
              'type'     => 'text',
              'title'    => __( 'Cabeçalho', 'redux-framework-demo' ),
              'subtitle' => __( '', 'redux-framework-demo' ),
              'desc'     => __( '', 'redux-framework-demo' ),
              'default'  => 'Encontre o ModaBiz mais próximo de você',
        ),

        //Elementos
        array(
            'id'       => 'comp-geo-el',
            'type'     => 'section',
            'title'    => __( 'Elementos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'comp-geo-icon',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Ícone do cabeçalho', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            'subtitle' => __( 'Formatos aceitos: png, jpg, svg e gif', 'redux-framework-demo' ),
            'default'  => array(
                'url'=> get_stylesheet_directory_uri() . '/images/icon-map.png',
            ),
        ),

        //Mapa
        /*array(
            'id'       => 'comp-map-conf',
            'type'     => 'section',
            'title'    => __( 'Configurações do mapa', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'             => 'comp-map-altura',
            'type'           => 'dimensions',
            'output'         => array('#map-layer'),
            'units'          => array( 'px','em' ),
            'title'          => __( 'Altura do painel', 'redux-framework-demo' ),
            'subtitle'       => __( '', 'redux-framework-demo' ),
            'desc'           => __( '', 'redux-framework-demo' ),
            'width'          => false,
            'default'        => array(
                'height' => '600px',
            )
        ),*/
    )
) );

?>