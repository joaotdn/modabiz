<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Seja revendedor', 'redux-framework-demo' ),
    'id'        => 'temp-revendedor',
    'desc'      => __( '', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Componentes
        array(
            'id'       => 'temp-revendedor-comp',
            'type'     => 'section',
            'title'    => __( 'Adicione componentes neste template', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'temp-revendedor-blocks-layout',
            'type'     => 'sorter',
            'title'    => 'Compor layout',
            'subtitle' => '',
            'compiler' => 'true',
            'options'  => array(
                'componentes'  => array(
                    'painel' => 'Painel',
                    'cadastro' => 'Cadastro',
                    'blog' => 'Blog',
                    'galeria' => 'Galeria',
                    'instagram-hash' => 'Instagram Hashtag',
                    'instagram-perfil' => 'Instagram perfil',
                    'geolocalizacao' => 'Geolocalização',
                ),
                'topo' => array(),
                'rodape' => array(),
            ),
        ),

        //informações
        array(
            'id'       => 'temp-revendedor-style-info',
            'type'     => 'section',
            'title'    => __( 'Estilo da página', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-reven-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#inner-revendedor'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#f1f1f1',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-reven-title',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#inner-revendedor h1'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '36px',
                'line-height' => '36px',
                'text-align'  => 'left',
                'font-weight' => '800'
            ),
        ),
        
        //informações
        array(
            'id'       => 'temp-revendedor-style-panel',
            'type'     => 'section',
            'title'    => __( 'Estilo do painel', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-revendedor-rgba',
            'type'     => 'color_rgba',
            'title'    => __( 'Máscara para o background', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'output'      => array('background-color' => '#panel-revendedor .mask'),
            'default'  => array(
                'color' => '#333333',
                'alpha' => '.8'
            ),
            //'output'   => array( 'body' ),
            'mode'     => 'background',
            'validate' => 'colorrgba',
        ),

        array(
            'id'          => 'temp-reven-panel-title',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#panel-revendedor h2'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#ffffff',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '40px',
                'line-height' => '40px',
                'font-weight' => '800'
            ),
        ),

        array(
            'id'          => 'temp-reven-panel-subtitle',
            'type'        => 'typography',
            'title'       => __('Fonte do subtítulo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#panel-revendedor h3'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#ffffff',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '20px',
                'line-height' => '20px',
                'font-weight' => '400'
            ),
        ),
        
        array(
            'id'          => 'temp-reven-panel-btn',
            'type'        => 'typography',
            'title'       => __('Fonte do botão', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.reven-btn-join'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'       => 'temp-reven-panel-btn-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('.reven-btn-join'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333333',
                'hover'   => '#eaeaea',
                'active'  => '#333333',
            ),
        ),

        array(
            'id'       => 'temp-reven-panel-btn-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.reven-btn-join'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-reven-panel-btn-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '.reven-btn-join:hover', 'border-color' => '.reven-btn-join:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'temp-reven-panel-btn-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.reven-btn-join'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '4px', 
                'border-right'  => '4px', 
                'border-bottom' => '4px', 
                'border-left'   => '4px'
            )
        ),

        //informações
        array(
            'id'       => 'temp-revendedor-style-info',
            'type'     => 'section',
            'title'    => __( 'Estilo do bloco de vantagens', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-revendedor-style-info-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '#reven-info'),
            'title'    => __('Cor de fundo do bloco', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-revendedor-style-info-title',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.reven-info-title'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'line-height' => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'          => 'temp-revendedor-style-info-desc',
            'type'        => 'typography',
            'title'       => __('Fonte da descrição', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.reven-info-desc'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'font-weight' => '400'
            ),
        ),

        //informações
        array(
            'id'       => 'temp-revendedor-style-form',
            'type'     => 'section',
            'title'    => __( 'Estilo do formulário', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-revendedor-style-form-contents-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.forms-content'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#f9f9f9',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-revendedor-style-form-font',
            'type'        => 'typography',
            'title'       => __('Fonte', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#reven-form h2, #reven-form h3, #reven-form input, #reven-form span, #reven-form label'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'font-family' => true,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => false,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
            ),
        ),

        array(
            'id'          => 'temp-revendedor-style-form-input-font',
            'type'        => 'typography',
            'title'       => __('Fonte dos inputs', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#reven-form input, #reven-form nav a'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => false,
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => false,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => true,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
            ),
        ),

        array( 
            'id'       => 'temp-revendedor-style-form-input-border',
            'type'     => 'border',
            'title'    => __('Borda do input', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('#reven-form input'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#999', 
                'border-style'  => 'solid', 
                'border-top'    => '1px', 
                'border-right'  => '1px', 
                'border-bottom' => '1px', 
                'border-left'   => '1px'
            )
        ),

        array(
            'id'          => 'temp-revendedor-style-form-btn',
            'type'        => 'typography',
            'title'       => __('Fonte do botão', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.reven-form-btn'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'       => 'temp-revendedor-style-form-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('.reven-form-btn'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333333',
                'hover'   => '#eaeaea',
                'active'  => '#333333',
            ),
        ),

        array(
            'id'       => 'temp-revendedor-style-form-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.reven-form-btn'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-revendedor-style-form-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '.reven-form-btn:hover', 'border-color' => '.reven-form-btn:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'temp-revendedor-style-form-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.reven-form-btn'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '4px', 
                'border-right'  => '4px', 
                'border-bottom' => '4px', 
                'border-left'   => '4px'
            )
        ),

        //bloco de informações
        array(
            'id'       => 'temp-revendedor-style-info-block',
            'type'     => 'section',
            'title'    => __( 'Estilo do bloco de informações', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-revendedor-style-infoblock-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.reven-info'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-revendedor-style-infoblock-titles',
            'type'        => 'typography',
            'title'       => __('Fonte dos títulos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.infoblock-title'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700',
                'text-align' => 'left',
            ),
        ),

        array(
            'id'          => 'temp-revendedor-style-infoblock-font',
            'type'        => 'typography',
            'title'       => __('Fonte do corpo', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.reven-info p, .reven-info li, .reven-info span'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '14px',
                'font-weight' => '400'
            ),
        ),

        array(
            'id'       => 'temp-revendedor-style-infoblock-check',
            'type'     => 'color',
            'output'      => array('color' => '.reven-info .icon-check-circle'),
            'title'    => __('Cor do ícone check', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#32d38d',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-revendedor-style-infoblock-contacts',
            'type'        => 'typography',
            'title'       => __('Fonte dos títulos de telefones', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('p.contact-title'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => false,
            'subsets' => false,
            'default'     => array(
                'color' => '#32d38d',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700',
                'text-align' => 'left',
            ),
        ),

        array(
            'id'          => 'temp-revendedor-style-infoblock-link',
            'type'        => 'typography',
            'title'       => __('Fonte de links', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.reven-info a'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => true,
            'line-height' => dalse,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => false,
            'subsets' => false,
            'default'     => array(
                'google'      => true,
                'font-size'   => '14px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'       => 'temp-revendedor-style-link-hover',
            'type'     => 'link_color',
            'title'    => __( 'Cor de links', 'redux-framework-demo' ),
            'output'      => array('.reven-info a'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333333',
                'hover'   => '#eaeaea',
                'active'  => '#333333',
            ),
        ),

        //bloco de depoimentos
        array(
            'id'       => 'temp-revendedor-style-testimonials',
            'type'     => 'section',
            'title'    => __( 'Estilo do bloco de depoimentos', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-revendedor-style-testimonials-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '#testimonials'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-revendedor-style-testimonials-quote',
            'type'     => 'color',
            'output'      => array('color' => '#testimonials .icon-quotes-left'),
            'title'    => __('Cor da aspas', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#454545',
            'validate' => 'color',
        ),

        array(
            'id'       => 'temp-revendedor-style-testimonials-nav',
            'type'     => 'color',
            'output'      => array('background-color' => '.testimonial-pager span','border-color' => '.testimonial-pager span','color' => '.testimonial-pager span'),
            'title'    => __('Cor da navegação', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-revendedor-style-testimonials-font',
            'type'        => 'typography',
            'title'       => __('Fonte dos depoimentos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#list-testimonials p'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'color' => '#ffffff',
                'google'      => true,
                'font-size'   => '16px',
                'font-weight' => '400',
                'line-height' => '24px'
            ),
        ),

        array(
            'id'          => 'temp-revendedor-style-testimonials-author',
            'type'        => 'typography',
            'title'       => __('Fonte dos autores', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => false,
            'output'      => array('#list-testimonials p.author-name'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            
            'color'      => true,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => false,
            'subsets' => false,
            'default'     => array(
                'color' => '#ffffff',
                'font-size'   => '16px',
                'font-weight' => '700'
            ),
        ),

        //bloco de informações
        array(
            'id'       => 'temp-revendedor-style-faq',
            'type'     => 'section',
            'title'    => __( 'Estilo do FAQ', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-revendedor-style-faq-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '#faq-section'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-revendedor-style-faq-header',
            'type'        => 'typography',
            'title'       => __('Fonte do título', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('h2.faq-header'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'color' => '#333333',
                'google'      => true,
                'font-size'   => '32px',
                'font-weight' => '700',
                'line-height' => '24px'
            ),
        ),

        array(
            'id'          => 'temp-revendedor-style-faq-font',
            'type'        => 'typography',
            'title'       => __('Fonte perguntas/respostas', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.faq-answer, .faq-reply'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'line-height' => true,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'color' => '#444444',
                'google'      => true,
                'font-size'   => '14px',
                'font-weight' => '400',
                'line-height' => '24px'
            ),
        ),

        array(
            'id'       => 'temp-revendedor-style-faq-answer',
            'type'     => 'color',
            'output'      => array('color' => '.faq-answer.active, .faq-answer:hover'),
            'title'    => __('Cor da pergunta suspensa', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#696969',
            'validate' => 'color',
        ),
) ));

?>