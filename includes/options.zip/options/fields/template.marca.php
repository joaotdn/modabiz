<?php
/**
 * Define estilos e elementos para compor o topo do tema
 */
Redux::setSection( $opt_name, array(
    'title'     => __( 'Quem somos', 'redux-framework-demo' ),
    'id'        => 'temp-marca',
    'desc'      => __( '', 'redux-framework-demo' ),
    'subsection'=> true,
    'fields'    => array(
        
        //Componentes
        array(
            'id'       => 'temp-marca-comp',
            'type'     => 'section',
            'title'    => __( 'Adicione componentes neste template', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'      => 'temp-marca-blocks-layout',
            'type'     => 'sorter',
            'title'    => 'Compor layout',
            'subtitle' => '',
            'compiler' => 'true',
            'options'  => array(
                'componentes'  => array(
                    'painel' => 'Painel',
                    'cadastro' => 'Cadastro',
                    'blog' => 'Blog',
                    'galeria' => 'Galeria',
                    'instagram-hash' => 'Instagram Hashtag',
                    'instagram-perfil' => 'Instagram perfil',
                    'geolocalizacao' => 'Geolocalização',
                ),
                'topo' => array(),
                'rodape' => array(),
            ),
        ),

        //informações
        array(
            'id'       => 'temp-marca-style-info',
            'type'     => 'section',
            'title'    => __( 'Estilos para o bloco de informações', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-marca-info-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#marca-info'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-marca-info-titles',
            'type'        => 'typography',
            'title'       => __('Fonte dos títulos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#marca-info h1,#marca-info h2,#marca-info h3,#marca-info h4,#marca-info h5,#marca-info h6'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '30px',
                'line-height' => '30px',
                'text-align'  => 'left',
            ),
        ),

        array(
            'id'          => 'temp-marca-info-txt-p',
            'type'        => 'typography',
            'title'       => __('Fonte dos parágrafos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#marca-info p'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#444444',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'text-align'  => 'left',
            ),
        ),

        //video
        array(
            'id'       => 'temp-marca-style-video',
            'type'     => 'section',
            'title'    => __( 'Estilos para o bloco de vídeo', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

        array(
            'id'       => 'temp-marca-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#marca-video'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#f8f8f8',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-marca-video-titles',
            'type'        => 'typography',
            'title'       => __('Fonte dos títulos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#marca-video h1,#marca-video h2,#marca-video h3,#marca-video h4,#marca-video h5,#marca-video h6'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '30px',
                'line-height' => '30px',
                'text-align'  => 'left',
            ),
        ),

        array(
            'id'          => 'temp-marca-info-txt',
            'type'        => 'typography',
            'title'       => __('Fonte dos parágrafos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#marca-video p'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#444444',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'text-align'  => 'left',
            ),
        ),

        //revendedor
        array(
            'id'       => 'temp-marca-style-reven',
            'type'     => 'section',
            'title'    => __( 'Estilos para o bloco seja revendedor', 'redux-framework-demo' ),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'indent'   => true,
        ),

         array(
            'id'       => 'temp-marca-reven-background',
            'type'     => 'color',
            'output'      => array('background-color' => '#marca-reven'),
            'title'    => __('Cor de fundo', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'          => 'temp-marca-reven-titles',
            'type'        => 'typography',
            'title'       => __('Fonte dos títulos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#marca-reven h1,#marca-reven h2,#marca-reven h3,#marca-reven h4,#marca-reven h5,#marca-reven h6'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '30px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#333333',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '30px',
                'line-height' => '30px',
                'text-align'  => 'left',
            ),
        ),

        array(
            'id'          => 'temp-marca-reven-txt',
            'type'        => 'typography',
            'title'       => __('Fonte dos parágrafos', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('#marca-reven p'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => true,
            'font-size'   => true,
            'font-family' => true,
            'line-height' => true,
            'text-align'  => true,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,

            'subsets' => false,
            'default'     => array(
                'color' => '#444444',
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '16px',
                'line-height' => '16px',
                'text-align'  => 'left',
            ),
        ),

        array(
            'id'          => 'comp-reven-btn-font',
            'type'        => 'typography',
            'title'       => __('Fonte do botão', 'redux-framework-demo'),
            'compiler'    => true,
            'google'      => true,
            'output'      => array('.reven-btn'),
            'units'       =>'px',
            'subtitle'    => __('', 'redux-framework-demo'),
            'preview'     => array(
                'always_display' => true,
                'font-size'   => '16px',
            ),
            
            'color'      => false,
            'font-size'   => false,
            'line-height' => false,
            'text-align'  => false,
            'font-style'  => false,
            'font-backup' => false,
            'font-weight' => true,
            'font-family' => true,
            'subsets' => false,
            'default'     => array(
                'font-family' => 'Open Sans',
                'google'      => true,
                'font-size'   => '18px',
                'font-weight' => '700'
            ),
        ),

        array(
            'id'       => 'comp-reven-btn-link',
            'type'     => 'link_color',
            'title'    => __( 'Cor da fonte do botão', 'redux-framework-demo' ),
            'output'      => array('.reven-btn'),
            'subtitle' => __( '', 'redux-framework-demo' ),
            'desc'     => __( '', 'redux-framework-demo' ),
            //'regular'   => false, 
            //'hover'     => false,
            'active'    => false, 
            'visited'   => false,
            'default'  => array(
                'regular' => '#333333',
                'hover'   => '#eaeaea',
                'active'  => '#333333',
            ),
        ),

        array(
            'id'       => 'comp-reven-button-bg',
            'type'     => 'color',
            'output'      => array('background-color' => '.reven-btn'),
            'title'    => __('Cor de fundo do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#ffffff',
            'validate' => 'color',
        ),

        array(
            'id'       => 'comp-reven-button-bg-hover',
            'type'     => 'color',
            'output'      => array('background-color' => '.reven-btn:hover', 'border-color' => '.reven-btn:hover'),
            'title'    => __('Cor de fundo do botão suspenso', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'default'  => '#333333',
            'validate' => 'color',
        ),

        array( 
            'id'       => 'comp-reven-button-border',
            'type'     => 'border',
            'title'    => __('Borda do botão', 'redux-framework-demo'),
            'subtitle' => __('', 'redux-framework-demo'),
            'output'   => array('.reven-btn'),
            'desc'     => __('', 'redux-framework-demo'),
            'default'  => array(
                'border-color'  => '#333333', 
                'border-style'  => 'solid', 
                'border-top'    => '4px', 
                'border-right'  => '4px', 
                'border-bottom' => '4px', 
                'border-left'   => '4px'
            )
        ),
) ));

?>